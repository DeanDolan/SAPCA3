// Express server that exposes insecure + secure login/register endpoints
// - Express basics: https://www.w3schools.com/nodejs/nodejs_express.asp
// - JS Map (in-memory lockout store): https://www.w3schools.com/js/js_maps.asp
// - Date.now() (timestamps): https://www.w3schools.com/jsref/jsref_now.asp
// - String.toLowerCase(): https://www.w3schools.com/jsref/jsref_tolowercase.asp
// - RegExp.test(): https://www.w3schools.com/jsref/jsref_regexp_test.asp
// - Template literals: https://www.w3schools.com/js/js_string_templates.asp

const path = require('path');
const fs = require('fs');
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit'); // helps against brute-force attempts
const winston = require('winston');              // structured logs to file
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// --- logging setup (JSON to logs/app.log)
fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true });
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [ new winston.transports.File({ filename: path.join(__dirname, 'logs', 'app.log') }) ],
});
const logEvent = (evt, fields = {}) => logger.info({ evt, ...fields });
const logWarn  = (evt, fields = {}) => logger.warn({ evt, ...fields });

// Connection pool improves DB performance vs single connections
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'secureapp',
  password: process.env.DB_PASSWORD || 'change-me',
  database: process.env.DB_NAME || 'secureapp',
  connectionLimit: 10
});

// parsers + static
app.use(express.urlencoded({ extended: false })); // parse form posts (HTML forms)
app.use(express.json());                          // parse JSON bodies (our /api/* endpoints)
app.get('/favicon.ico', (req, res) => res.status(204).end()); // quiet favicon
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// --- metrics + request logger (status + duration)
const metrics = { totalRequests: 0, loginFailed: 0, lockedOut: 0 };
app.use((req, res, next) => {
  if (req.path === '/favicon.ico') return next();
  const start = Date.now();
  res.on('finish', () => {
    metrics.totalRequests += 1;
    logger.info({
      evt: 'http',
      method: req.method,
      url: req.originalUrl || req.url,
      status: res.statusCode,
      duration_ms: Date.now() - start,
      ip: req.ip
    });
  });
  next();
});

// health + metrics
app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime(), timestamp: Date.now() }));
app.get('/metrics', (req, res) => res.json(metrics));

/* ----------------------- Helpers for secure lockout ----------------------- */
// Simple in-memory lockout per (username, ip) / Good for demo - resets on restart
// W3S Map: https://www.w3schools.com/js/js_maps.asp
// W3S Date.now(): https://www.w3schools.com/jsref/jsref_now.asp
// W3S toLowerCase(): https://www.w3schools.com/jsref/jsref_tolowercase.asp
const attempts = new Map(); // key: `${usernameLower}|${ip}` -> { count, first, lockUntil }
const WINDOW_MS = 15 * 60 * 1000; // lock window
const MAX_FAILS = 5;              // attempts before lock
const LOCK_MS = 15 * 60 * 1000;   // lock duration

function keyFor(username, ip) { return `${String(username || '').toLowerCase()}|${ip}`; }
function now() { return Date.now(); }
function remaining(ms) {
  const s = Math.ceil(ms / 1000), m = Math.floor(s / 60), r = s % 60;
  return `${m}m ${r}s`;
}
function checkLocked(username, ip) {
  const k = keyFor(username, ip);
  const rec = attempts.get(k);
  if (!rec) return { locked: false };
  if (rec.lockUntil && rec.lockUntil > now()) {
    return { locked: true, msg: `Too many attempts. Try again in ${remaining(rec.lockUntil - now())}` };
  }
  if (rec.first && (now() - rec.first) > WINDOW_MS) {
    attempts.delete(k);
    return { locked: false };
  }
  return { locked: false };
}
function registerFailure(username, ip) {
  const k = keyFor(username, ip);
  const rec = attempts.get(k) || { count: 0, first: now(), lockUntil: 0 };
  if (now() - rec.first > WINDOW_MS) { rec.count = 0; rec.first = now(); rec.lockUntil = 0; }
  rec.count += 1;
  if (rec.count >= MAX_FAILS) { rec.lockUntil = now() + LOCK_MS; metrics.lockedOut += 1; logWarn('lockout', { user: username, ip }); }
  attempts.set(k, rec);
}
function clearAttempts(username, ip) { attempts.delete(keyFor(username, ip)); }

/* ----------------------- INSECURE HTML routes ----------------------- */
// Deliberately vulnerable (SQL concatenation, plaintext passwords, non generic messages)
app.post('/insecure/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [found] = await pool.query("SELECT id, password_plain FROM users WHERE username='" + username + "'");
    if (!found.length) {
      metrics.loginFailed += 1;
      logEvent('auth_fail', { type: 'insecure', reason: 'user_not_found', ip: req.ip });
      return res.send(`<h1>User does not exist (INSECURE)</h1><p><a href="/login.html">Back</a></p>`);
    }
    const [rows] = await pool.query("SELECT id FROM users WHERE username='" + username + "' AND password_plain='" + password + "'");
    if (!rows.length) {
      metrics.loginFailed += 1;
      logEvent('auth_fail', { type: 'insecure', reason: 'bad_password', ip: req.ip });
      return res.send(`<h1>Wrong password (INSECURE)</h1><p><a href="/login.html">Back</a></p>`);
    }
    logEvent('auth_ok', { type: 'insecure', user: username, ip: req.ip });
    return res.send(`<h1>Logged in (INSECURE)</h1><p>Welcome ${username}</p><p><a href="/login.html">Back</a></p>`);
  } catch (err) {
    return res.status(500).send(`<h1>Error (INSECURE)</h1><pre>${err.message}</pre><p><a href="/login.html">Back</a></p>`);
  }
});

app.post('/insecure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.send(`<h1>Missing fields (INSECURE)</h1><p><a href="/login.html">Back</a></p>`);
  if (password !== confirm) return res.send(`<h1>Passwords do not match (INSECURE)</h1><p><a href="/login.html">Back</a></p>`);
  try {
    await pool.query("INSERT INTO users(username, password_plain, password_hash) VALUES ('" + username + "', '" + password + "', '')");
    logEvent('register_ok', { type: 'insecure', user: username });
    return res.send(`<h1>Registered (INSECURE)</h1><p><a href="/login.html">Back</a></p>`);
  } catch (err) {
    return res.status(500).send(`<h1>DB Error (INSECURE)</h1><pre>${err.message}</pre><p><a href="/login.html">Back</a></p>`);
  }
});

/* ----------------------- INSECURE JSON API (for banners) ----------------------- */
app.post('/api/insecure/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [found] = await pool.query("SELECT id, password_plain FROM users WHERE username='" + username + "'");
    if (!found.length) { metrics.loginFailed += 1; logEvent('auth_fail', { type:'insecure', reason:'user_not_found', ip: req.ip }); return res.json({ ok: false, message: 'User does not exist (INSECURE)' }); }
    const [rows] = await pool.query("SELECT id FROM users WHERE username='" + username + "' AND password_plain='" + password + "'");
    if (!rows.length) { metrics.loginFailed += 1; logEvent('auth_fail', { type:'insecure', reason:'bad_password', ip: req.ip }); return res.json({ ok: false, message: 'Wrong password (INSECURE)' }); }
    logEvent('auth_ok', { type:'insecure', user: username, ip: req.ip });
    return res.json({ ok: true, message: `Logged in (INSECURE) – Welcome ${username}` });
  } catch (err) {
    return res.status(500).json({ ok: false, message: `Error (INSECURE): ${err.message}` });
  }
});

app.post('/api/insecure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.json({ ok: false, message: 'Missing fields (INSECURE)' });
  if (password !== confirm) return res.json({ ok: false, message: 'Passwords do not match (INSECURE)' });
  try {
    await pool.query("INSERT INTO users(username, password_plain, password_hash) VALUES ('" + username + "', '" + password + "', '')");
    logEvent('register_ok', { type:'insecure', user: username });
    return res.json({ ok: true, message: 'Registered (INSECURE) – PLAINTEXT stored' });
  } catch (err) {
    const msg = err.code === 'ER_DUP_ENTRY' ? 'Username exists (INSECURE)' : `DB Error (INSECURE): ${err.message}`;
    return res.status(400).json({ ok: false, message: msg });
  }
});

/* ----------------------- SECURE RATE LIMIT (IP) ----------------------- */
// Throttle per-IP login attempts (defense-in-depth against brute force)
// Express intro: https://www.w3schools.com/nodejs/nodejs_express.asp
const secureLoginLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, message: 'Too many attempts from this IP. Please try again shortly.' }
});

/* ----------------------- SECURE JSON API (with lockout + bcrypt) ----------------------- */
// Prepared statements + bcrypt; generic errors avoid user enumeration
// W3S RegExp.test(): https://www.w3schools.com/jsref/jsref_regexp_test.asp (used client-side too)
app.post('/api/secure/login', secureLoginLimiter, async (req, res) => {
  const { username, password } = req.body;
  const ip = req.ip;
  const GENERIC = 'Invalid username or password';

  const status = checkLocked(username, ip);
  if (status.locked) { logWarn('lockout', { user: username, ip }); return res.json({ ok: false, message: status.msg }); }

  try {
    const [rows] = await pool.execute('SELECT id, password_hash FROM users WHERE username = ?', [username]);
    if (!rows.length) { metrics.loginFailed += 1; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'user_not_found', ip }); return res.json({ ok: false, message: GENERIC }); }
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) { metrics.loginFailed += 1; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'bad_password', ip }); return res.json({ ok: false, message: GENERIC }); }
    clearAttempts(username, ip);
    logEvent('auth_ok', { type:'secure', user: username, ip });
    return res.json({ ok: true, message: `Logged in (SECURE) – Welcome ${username}` });
  } catch {
    return res.status(500).json({ ok: false, message: 'Try again later' });
  }
});

app.post('/api/secure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.json({ ok: false, message: 'Missing fields' });
  if (password !== confirm) return res.json({ ok: false, message: 'Passwords do not match' });

  // Server-side password policy
  const p = String(password || '').trim();
  if (p.length < 12) return res.json({ ok: false, message: 'Weak password: at least 12 characters' });
  if (!/[a-z]/.test(p)) return res.json({ ok: false, message: 'Weak password: add a lowercase letter' });
  if (!/[A-Z]/.test(p)) return res.json({ ok: false, message: 'Weak password: add an uppercase letter' });
  if (!/[0-9]/.test(p)) return res.json({ ok: false, message: 'Weak password: add a number' });
  if (!/[^A-Za-z0-9]/.test(p)) return res.json({ ok: false, message: 'Weak password: add a symbol' });
  if (p.toLowerCase().includes(String(username).toLowerCase())) return res.json({ ok: false, message: 'Weak password: must not contain the username' });

  try {
    const hash = await bcrypt.hash(p, 12); // store hashes only, never plaintext
    await pool.execute('INSERT INTO users(username, password_plain, password_hash) VALUES (?,?,?)', [username, '', hash]);
    logEvent('register_ok', { type:'secure', user: username });
    return res.json({ ok: true, message: 'Registration successful' });
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.json({ ok: false, message: 'Username already taken' });
    return res.status(500).json({ ok: false, message: 'Server error' });
  }
});

/* ----------------------- SECURE HTML ----------------------- */
// Keep for contrast in screenshots  banners use /api/*
app.post('/secure/login', secureLoginLimiter, async (req, res) => {
  const { username, password } = req.body;
  const ip = req.ip;
  const GENERIC = 'Invalid username or password';

  const status = checkLocked(username, ip);
  if (status.locked) { logWarn('lockout', { user: username, ip }); return res.send(`<h1>${status.msg}</h1><p><a href="/login.html">Back</a></p>`); }

  try {
    const [rows] = await pool.execute('SELECT id, password_hash FROM users WHERE username = ?', [username]);
    if (!rows.length) { metrics.loginFailed += 1; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'user_not_found', ip }); return res.send(`<h1>${GENERIC}</h1><p><a href="/login.html">Back</a></p>`); }
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) { metrics.loginFailed += 1; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'bad_password', ip }); return res.send(`<h1>${GENERIC}</h1><p><a href="/login.html">Back</a></p>`); }
    clearAttempts(username, ip);
    logEvent('auth_ok', { type:'secure', user: username, ip });
    return res.send(`<h1>Logged in (SECURE)</h1><p><a href="/login.html">Back</a></p>`);
  } catch {
    return res.status(500).send(`<h1>Try again later</h1><p><a href="/login.html">Back</a></p>`);
  }
});

app.post('/secure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.send(`<h1>Missing fields</h1><p><a href="/login.html">Back</a></p>`);
  if (password !== confirm) return res.send(`<h1>Passwords do not match</h1><p><a href="/login.html">Back</a></p>`);
  const p = String(password || '').trim();
  if (p.length < 12 || !/[a-z]/.test(p) || !/[A-Z]/.test(p) || !/[0-9]/.test(p) || !/[^A-Za-z0-9]/.test(p) || p.toLowerCase().includes(String(username).toLowerCase())){
    return res.send(`<h1>Weak password</h1><p>Use ≥12 chars incl. upper, lower, number, symbol; must not contain username.</p><p><a href="/login.html">Back</a></p>`);
  }
  try {
    const hash = await bcrypt.hash(p, 12);
    await pool.execute('INSERT INTO users(username, password_plain, password_hash) VALUES (?,?,?)', [username, '', hash]);
    logEvent('register_ok', { type:'secure', user: username });
    return res.send(`<h1>Registration successful</h1><p><a href="/login.html">Go to Login</a></p>`);
  } catch (err) {
    if (err.code === 'ER_DUP_ENTRY') return res.send(`<h1>Username already taken</h1><p><a href="/login.html">Back</a></p>`);
    return res.status(500).send(`<h1>Server error</h1><p><a href="/login.html">Back</a></p>`);
  }
});

// errors (generic 500; avoid leaking secrets)
app.use((err, req, res, next) => {
  logger.error({ evt: 'error', method: req.method, url: req.url, ip: req.ip, name: err.name, message: err.message });
  res.status(500).send('<h1>Server error</h1><p><a href="/login.html">Back</a></p>');
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
