// Express server that exposes insecure + secure login/register endpoints
// - Express basics https://www.w3schools.com/nodejs/nodejs_express.asp
// - JS Map https://www.w3schools.com/js/js_maps.asp
// - Date.now https://www.w3schools.com/jsref/jsref_now.asp
// - String.toLowerCase https://www.w3schools.com/jsref/jsref_tolowercase.asp
// - RegExp.test https://www.w3schools.com/jsref/jsref_regexp_test.asp
// - Template literals https://www.w3schools.com/js/js_string_templates.asp

const path = require('path');
const fs = require('fs');
const express = require('express');
const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit');
const winston = require('winston');
const session = require('express-session');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// logging
fs.mkdirSync(path.join(__dirname, 'logs'), { recursive: true });
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [ new winston.transports.File({ filename: path.join(__dirname, 'logs', 'app.log') }) ],
});
const logEvent = (evt, fields = {}) => logger.info({ evt, ...fields });
const logWarn  = (evt, fields = {}) => logger.warn({ evt, ...fields });

// db
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'secureapp',
  password: process.env.DB_PASSWORD || 'change-me',
  database: process.env.DB_NAME || 'secureapp',
  connectionLimit: 10
});

// middleware
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'dev-only-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax' }
}));
app.get('/favicon.ico', (req, res) => res.status(204).end());
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.use(express.static(path.join(__dirname, 'public'), { index: false }));

// metrics + http logs
const metrics = { totalRequests: 0, loginFailed: 0, lockedOut: 0, notesPostedInsecure: 0, notesPostedSecure: 0 };
app.use((req, res, next) => {
  if (req.path === '/favicon.ico') return next();
  const start = Date.now();
  res.on('finish', () => {
    metrics.totalRequests += 1;
    logger.info({
      evt: 'http',
      method: req.method,
      url: req.originalUrl || req.url,
      status: res.statusCode,
      duration_ms: Date.now() - start,
      ip: req.ip
    });
  });
  next();
});
app.get('/health', (req, res) => res.json({ status: 'ok', uptime: process.uptime(), timestamp: Date.now() }));
app.get('/metrics', (req, res) => res.json(metrics));

// helpers
const attempts = new Map();
const WINDOW_MS = 15 * 60 * 1000;
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;
function keyFor(username, ip) { return `${String(username || '').toLowerCase()}|${ip}`; }
function now() { return Date.now(); }
function remaining(ms) { const s = Math.ceil(ms/1000), m = Math.floor(s/60), r = s%60; return `${m}m ${r}s`; }
function checkLocked(username, ip) {
  const k = keyFor(username, ip);
  const rec = attempts.get(k);
  if (!rec) return { locked: false };
  if (rec.lockUntil && rec.lockUntil > now()) return { locked: true, msg: `Too many attempts. Try again in ${remaining(rec.lockUntil - now())}` };
  if (rec.first && (now() - rec.first) > WINDOW_MS) { attempts.delete(k); }
  return { locked: false };
}
function registerFailure(username, ip) {
  const k = keyFor(username, ip);
  const rec = attempts.get(k) || { count: 0, first: now(), lockUntil: 0 };
  if (now() - rec.first > WINDOW_MS) { rec.count = 0; rec.first = now(); rec.lockUntil = 0; }
  rec.count += 1;
  if (rec.count >= MAX_FAILS) { rec.lockUntil = now() + LOCK_MS; metrics.lockedOut += 1; logWarn('lockout', { user: username, ip }); }
  attempts.set(k, rec);
}
function clearAttempts(username, ip) { attempts.delete(keyFor(username, ip)); }
function requireAuth(req, res, next) {
  if (!req.session || !req.session.username) return res.status(401).send('<h1>Login required</h1><p><a href="/login.html">Back</a></p>');
  next();
}
function htmlEscape(s = '') {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}


(async () => {
  try {
    await pool.execute(`
      CREATE TABLE IF NOT EXISTS notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        owner VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('notes table ready');
  } catch (e) {
    console.error('notes table error:', e.message);
  }
})();

/* ---------------- INSECURE login/register (HTML + JSON) ---------------- */
app.post('/insecure/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [found] = await pool.query("SELECT id,password_plain FROM users WHERE username='" + username + "'");
    if (!found.length) { metrics.loginFailed++; logEvent('auth_fail', { type: 'insecure', reason: 'user_not_found', ip: req.ip }); return res.send('<h1>User does not exist (INSECURE)</h1><p><a href="/login.html">Back</a></p>'); }
    const [rows] = await pool.query("SELECT id FROM users WHERE username='" + username + "' AND password_plain='" + password + "'");
    if (!rows.length) { metrics.loginFailed++; logEvent('auth_fail', { type: 'insecure', reason: 'bad_password', ip: req.ip }); return res.send('<h1>Wrong password (INSECURE)</h1><p><a href="/login.html">Back</a></p>'); }
    logEvent('auth_ok', { type: 'insecure', user: username, ip: req.ip });
    return res.send(`<h1>Logged in (INSECURE)</h1><p>Welcome ${username}</p><p><a href="/login.html">Back</a></p>`);
  } catch (err) { return res.status(500).send(`<h1>Error (INSECURE)</h1><pre>${err.message}</pre><p><a href="/login.html">Back</a></p>`); }
});
app.post('/insecure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.send('<h1>Missing fields (INSECURE)</h1><p><a href="/login.html">Back</a></p>');
  if (password !== confirm) return res.send('<h1>Passwords do not match (INSECURE)</h1><p><a href="/login.html">Back</a></p>');
  try { await pool.query("INSERT INTO users(username,password_plain,password_hash) VALUES ('"+username+"','"+password+"','')"); logEvent('register_ok', { type: 'insecure', user: username }); return res.send('<h1>Registered (INSECURE)</h1><p><a href="/login.html">Back</a></p>'); }
  catch (err) { return res.status(500).send(`<h1>DB Error (INSECURE)</h1><pre>${err.message}</pre><p><a href="/login.html">Back</a></p>`); }
});
app.post('/api/insecure/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [found] = await pool.query("SELECT id,password_plain FROM users WHERE username='" + username + "'");
    if (!found.length) { metrics.loginFailed++; logEvent('auth_fail', { type:'insecure', reason:'user_not_found', ip: req.ip }); return res.json({ ok:false, message:'User does not exist (INSECURE)' }); }
    const [rows] = await pool.query("SELECT id FROM users WHERE username='" + username + "' AND password_plain='" + password + "'");
    if (!rows.length) { metrics.loginFailed++; logEvent('auth_fail', { type:'insecure', reason:'bad_password', ip: req.ip }); return res.json({ ok:false, message:'Wrong password (INSECURE)' }); }
    logEvent('auth_ok', { type:'insecure', user: username, ip: req.ip });
    return res.json({ ok:true, message:`Logged in (INSECURE) – Welcome ${username}` });
  } catch (err) { return res.status(500).json({ ok:false, message:`Error (INSECURE): ${err.message}` }); }
});
app.post('/api/insecure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.json({ ok:false, message:'Missing fields (INSECURE)' });
  if (password !== confirm) return res.json({ ok:false, message:'Passwords do not match (INSECURE)' });
  try { await pool.query("INSERT INTO users(username,password_plain,password_hash) VALUES ('"+username+"','"+password+"','')"); logEvent('register_ok', { type:'insecure', user: username }); return res.json({ ok:true, message:'Registered (INSECURE) – PLAINTEXT stored' }); }
  catch (err) { const msg = err.code === 'ER_DUP_ENTRY' ? 'Username exists (INSECURE)' : `DB Error (INSECURE): ${err.message}`; return res.status(400).json({ ok:false, message: msg }); }
});

/* ---------------- SECURE login/register (JSON + HTML) ---------------- */
const secureLoginLimiter = rateLimit({ windowMs: 60*1000, max: 10, standardHeaders:true, legacyHeaders:false,
  message: { ok:false, message:'Too many attempts from this IP. Please try again shortly.' } });

app.post('/api/secure/login', secureLoginLimiter, async (req, res) => {
  const { username, password } = req.body; const ip = req.ip; const GENERIC = 'Invalid username or password';
  const status = checkLocked(username, ip); if (status.locked) { logWarn('lockout', { user: username, ip }); return res.json({ ok:false, message: status.msg }); }
  try {
    const [rows] = await pool.execute('SELECT id, password_hash FROM users WHERE username = ?', [username]);
    if (!rows.length) { metrics.loginFailed++; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'user_not_found', ip }); return res.json({ ok:false, message: GENERIC }); }
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) { metrics.loginFailed++; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'bad_password', ip }); return res.json({ ok:false, message: GENERIC }); }
    clearAttempts(username, ip);
    req.session.username = username; // set session
    logEvent('auth_ok', { type:'secure', user: username, ip });
    return res.json({ ok:true, message:`Logged in (SECURE) – Welcome ${username}` });
  } catch { return res.status(500).json({ ok:false, message:'Try again later' }); }
});
app.post('/api/secure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.json({ ok:false, message:'Missing fields' });
  if (password !== confirm) return res.json({ ok:false, message:'Passwords do not match' });
  const p = String(password || '').trim();
  if (p.length < 12) return res.json({ ok:false, message:'Weak password: at least 12 characters' });
  if (!/[a-z]/.test(p)) return res.json({ ok:false, message:'Weak password: add a lowercase letter' });
  if (!/[A-Z]/.test(p)) return res.json({ ok:false, message:'Weak password: add an uppercase letter' });
  if (!/[0-9]/.test(p)) return res.json({ ok:false, message:'Weak password: add a number' });
  if (!/[^A-Za-z0-9]/.test(p)) return res.json({ ok:false, message:'Weak password: add a symbol' });
  if (p.toLowerCase().includes(String(username).toLowerCase())) return res.json({ ok:false, message:'Weak password: must not contain the username' });
  try { const hash = await bcrypt.hash(p, 12); await pool.execute('INSERT INTO users(username,password_plain,password_hash) VALUES (?,?,?)', [username, '', hash]); logEvent('register_ok', { type:'secure', user: username }); return res.json({ ok:true, message:'Registration successful' }); }
  catch (err) { if (err.code === 'ER_DUP_ENTRY') return res.json({ ok:false, message:'Username already taken' }); return res.status(500).json({ ok:false, message:'Server error' }); }
});
app.post('/secure/login', secureLoginLimiter, async (req, res) => {
  const { username, password } = req.body; const ip = req.ip; const GENERIC = 'Invalid username or password';
  const status = checkLocked(username, ip); if (status.locked) { logWarn('lockout', { user: username, ip }); return res.send(`<h1>${status.msg}</h1><p><a href="/login.html">Back</a></p>`); }
  try {
    const [rows] = await pool.execute('SELECT id, password_hash FROM users WHERE username = ?', [username]);
    if (!rows.length) { metrics.loginFailed++; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'user_not_found', ip }); return res.send(`<h1>${GENERIC}</h1><p><a href="/login.html">Back</a></p>`); }
    const ok = await bcrypt.compare(password, rows[0].password_hash);
    if (!ok) { metrics.loginFailed++; registerFailure(username, ip); logEvent('auth_fail', { type:'secure', reason:'bad_password', ip }); return res.send(`<h1>${GENERIC}</h1><p><a href="/login.html">Back</a></p>`); }
    clearAttempts(username, ip);
    req.session.username = username;
    logEvent('auth_ok', { type:'secure', user: username, ip });
    return res.send('<h1>Logged in (SECURE)</h1><p><a href="/login.html">Back</a></p>');
  } catch { return res.status(500).send('<h1>Try again later</h1><p><a href="/login.html">Back</a></p>'); }
});
app.post('/secure/register', async (req, res) => {
  const { username, password, confirm } = req.body;
  if (!username || !password || !confirm) return res.send('<h1>Missing fields</h1><p><a href="/login.html">Back</a></p>');
  if (password !== confirm) return res.send('<h1>Passwords do not match</h1><p><a href="/login.html">Back</a></p>');
  const p = String(password || '').trim();
  if (p.length < 12 || !/[a-z]/.test(p) || !/[A-Z]/.test(p) || !/[0-9]/.test(p) || !/[^A-Za-z0-9]/.test(p) || p.toLowerCase().includes(String(username).toLowerCase())){
    return res.send('<h1>Weak password</h1><p>Use ≥12 chars incl. upper, lower, number, symbol; must not contain username.</p><p><a href="/login.html">Back</a></p>');
  }
  try { const hash = await bcrypt.hash(p, 12); await pool.execute('INSERT INTO users(username,password_plain,password_hash) VALUES (?,?,?)', [username, '', hash]); logEvent('register_ok', { type:'secure', user: username }); return res.send('<h1>Registration successful</h1><p><a href="/login.html">Go to Login</a></p>'); }
  catch (err) { if (err.code === 'ER_DUP_ENTRY') return res.send('<h1>Username already taken</h1><p><a href="/login.html">Back</a></p>'); return res.status(500).send('<h1>Server error</h1><p><a href="/login.html">Back</a></p>'); }
});

/* ---------------- NOTES pages & APIs ---------------- */
// Insecure pages
app.get('/insecure/notes', async (req, res) => {
  const [rows] = await pool.query('SELECT owner, content, created_at FROM notes ORDER BY id DESC LIMIT 50');
  const list = rows.map(r => `<li><b>${r.owner}</b>: ${r.content} <i>(${r.created_at})</i></li>`).join('');
  res.send(`
    <h1>Insecure Notes</h1>
    <form method="post" action="/insecure/notes">
      <label>Owner <input name="owner" required placeholder="name"></label>
      <label>Content <textarea name="content" placeholder="can inject <script> here"></textarea></label>
      <button type="submit">Post (Insecure)</button>
    </form>
    <h2>All Notes (raw)</h2>
    <ul>${list || '<li>None</li>'}</ul>
    <p><a href="/notes.html">Back</a></p>
  `);
});
app.post('/insecure/notes', async (req, res) => {
  const owner = String(req.body.owner || 'anon');
  const content = String(req.body.content || '');
  metrics.notesPostedInsecure += 1;
  await pool.execute('INSERT INTO notes(owner, content) VALUES (?, ?)', [owner, content]);
  res.redirect('/insecure/notes');
});

// Secure pages
app.get('/secure/notes', requireAuth, async (req, res) => {
  const [rows] = await pool.execute('SELECT content, created_at FROM notes WHERE owner = ? ORDER BY id DESC LIMIT 50', [req.session.username]);
  const list = rows.map(r => `<li>${htmlEscape(r.content)} <i>(${r.created_at})</i></li>`).join('');
  res.send(`
    <h1>Secure Notes</h1>
    <form method="post" action="/secure/notes">
      <textarea name="content" placeholder="stored safely (encoded on render)" required maxlength="1000"></textarea>
      <button>Post (Secure)</button>
    </form>
    <h2>Your Notes (encoded)</h2>
    <ul>${list || '<li>None</li>'}</ul>
    <p><a href="/notes.html">Back</a></p>
  `);
});
app.post('/secure/notes', requireAuth, async (req, res) => {
  const content = String(req.body.content || '').trim();
  if (!content || content.length > 1000) return res.status(400).send('<h1>Invalid content</h1><p><a href="/secure/notes">Back</a></p>');
  metrics.notesPostedSecure += 1;
  await pool.execute('INSERT INTO notes(owner, content) VALUES (?, ?)', [req.session.username, content]);
  res.redirect('/secure/notes');
});

// Secure Notes JSON API for AJAX
app.get('/api/secure/notes', requireAuth, async (req, res) => {
  const [rows] = await pool.execute(
    'SELECT content, created_at FROM notes WHERE owner = ? ORDER BY id DESC LIMIT 10',
    [req.session.username]
  );
  res.json({ ok: true, items: rows });
});
app.post('/api/secure/notes', requireAuth, async (req, res) => {
  const content = String(req.body.content || '').trim();
  if (!content || content.length > 1000) return res.status(400).json({ ok:false, message:'Invalid content' });
  await pool.execute('INSERT INTO notes(owner, content) VALUES (?, ?)', [req.session.username, content]);
  const [rows] = await pool.execute(
    'SELECT content, created_at FROM notes WHERE owner = ? ORDER BY id DESC LIMIT 10',
    [req.session.username]
  );
  res.json({ ok: true, message: 'Saved', items: rows });
});

// logout
app.get('/secure/logout', (req, res) => { req.session.destroy(() => res.redirect('/login.html')); });

// errors
app.use((err, req, res, next) => {
  logger.error({ evt: 'error', method: req.method, url: req.url, ip: req.ip, name: err.name, message: err.message });
  res.status(500).send('<h1>Server error</h1><p><a href="/login.html">Back</a></p>');
});

app.listen(PORT, () => { console.log(`Server running at http://localhost:${PORT}`); });
