CREATE DATABASE IF NOT EXISTS secureapp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'secureapp'@'localhost' IDENTIFIED BY 'change-me';
GRANT ALL ON secureapp.* TO 'secureapp'@'localhost';
FLUSH PRIVILEGES;

USE secureapp;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(255) UNIQUE NOT NULL,
  password_plain VARCHAR(255) NOT NULL,   -- INSECURE: plaintext for demo only
  password_hash VARCHAR(255) NOT NULL,    -- SECURE: bcrypt hash
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);