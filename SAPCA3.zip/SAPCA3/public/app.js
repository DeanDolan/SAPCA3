// Minimal controller for login/register tabs + submit + redirect on success
// Works for both insecure (/api/insecure/*) and secure (/api/secure/*)

window.addEventListener('DOMContentLoaded', () => {
  let CSRF = '';

  // helpers
  const $ = (id) => document.getElementById(id);
  const on = (id, ev, fn) => { const el=$(id); if (el) el.addEventListener(ev, fn); };

  function setActive(kind, tab){
    const other = tab === 'login' ? 'register' : 'login';
    $(`pane-${kind}-${tab}`).classList.add('active');
    $(`pane-${kind}-${other}`).classList.remove('active');
    $(`btn-${kind}-${tab}`).classList.add('btn-active');
    $(`btn-${kind}-${other}`).classList.remove('btn-active');
  }
  function showBanner(kind, tab, ok, msg){
    const el = $(`banner-${kind}-${tab}`);
    if (!el) return;
    el.textContent = msg;
    el.className = `banner ${ok ? 'banner--success' : 'banner--error'}`;
  }

  async function ensureCsrf(){
    if (CSRF) return CSRF;
    try {
      const r = await fetch('/api/csrf', { credentials: 'same-origin' });
      if (r.ok) {
        const j = await r.json();
        CSRF = j.csrfToken || '';
      }
    } catch {}
    return CSRF;
  }

  async function submitForm(kind, tab){
    const form = $(`form-${kind}-${tab}`);
    const endpoint = form?.dataset?.endpoint;
    if (!form || !endpoint) { showBanner(kind, tab, false, 'Form not found'); return; }

    const data = new URLSearchParams(new FormData(form));

    // client checks for register flows
    if (tab === 'register' && kind === 'secure'){
      const u = data.get('username');
      const p1 = $('s-p1')?.value || '';
      const p2 = $('s-p2')?.value || '';
      if (p1 !== p2) { showBanner(kind, tab, false, 'Passwords do not match'); return; }
      const p = p1.trim();
      if (p.length < 12 || !/[a-z]/.test(p) || !/[A-Z]/.test(p) || !/[0-9]/.test(p) || !/[^A-Za-z0-9]/.test(p) || (u && p.toLowerCase().includes(String(u).toLowerCase()))) {
        showBanner(kind, tab, false, 'Weak password policy not met');
        return;
      }
    } else if (tab === 'register' && kind === 'insecure'){
      const p1 = $('i-p1')?.value || '';
      const p2 = $('i-p2')?.value || '';
      if (p1 !== p2) { showBanner(kind, tab, false, 'Passwords do not match (INSECURE)'); return; }
    }

    try {
      const headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
      if (endpoint.startsWith('/api/secure/')) {
        await ensureCsrf();
        if (CSRF) headers['CSRF-Token'] = CSRF;
      }
      const r = await fetch(endpoint, { method: 'POST', headers, body: data, credentials: 'same-origin' });
      const ct = r.headers.get('content-type') || '';
      const j = ct.includes('application/json') ? await r.json() : { ok: r.ok, message: await r.text() };

      showBanner(kind, tab, !!j.ok, j.message || (j.ok ? 'OK' : 'Error'));

      // >>> redirect after successful LOGIN
      if (j && j.ok && tab === 'login') {
        window.location.href = '/notes.html';
        return;
      }
    } catch {
      showBanner(kind, tab, false, 'Network error');
    }
  }

  function onTabClick(kind, tab){
    const pane = $(`pane-${kind}-${tab}`);
    if (!pane) return;
    if (!pane.classList.contains('active')) { setActive(kind, tab); return; }
    submitForm(kind, tab);
  }

  // bind buttons
  on('btn-insecure-login',    'click', () => onTabClick('insecure','login'));
  on('btn-insecure-register', 'click', () => onTabClick('insecure','register'));
  on('btn-secure-login',      'click', () => onTabClick('secure','login'));
  on('btn-secure-register',   'click', () => onTabClick('secure','register'));
});
